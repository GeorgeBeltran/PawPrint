
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;;

@SuppressWarnings("unused")
public class adoptDog {
	public Label dogSizeLabel2 = new Label("Dog Size");
	public ComboBox<String> dogSizeComboBox2 = new ComboBox<>();
	public Label dogBreedLabel2 = new Label("Dog Breed");
	public ComboBox<String> dogBreedComboBox2 = new ComboBox<>();
	public Label dogGenderLabel2 = new Label("Dog Gender");
	public ComboBox<String> dogGenderCombobox2 = new ComboBox<>();
	public Label dogColorLabel2 = new Label("Dog Color");
	public ComboBox<String> dogColorComboBox2 = new ComboBox<>();
	public Label dogAgeLabel2 = new Label("Dog Age");
	public ComboBox<String> dogAgeComboBox2 = new ComboBox<>();
	
	// Button and Label for going back to loginScene
	Label loginSceneLabel = new Label("Back To Login");
	Button backToLoginButton = new Button("Click Here!!");
	
	// Button and Label for going to next Scene
	Label goToListLabel = new Label("Go to List");
	Button goToListButton = new Button("Click Here!!");
	
	public VBox adoptDogScene = new VBox();
	
	public adoptDog()
	{

		
		//Size
		dogSizeComboBox2.getItems().addAll("","Small","Medium","Large");
		dogSizeComboBox2.setVisibleRowCount(5);
		dogSizeComboBox2.getSelectionModel().select(0);
		
		//Breed
		dogBreedComboBox2.getItems().addAll("");
		String [] dogBreeds = GUI.readDogBreedsIntoArray("src\\DogBreeds.txt");
		for(String breed: dogBreeds)
		{
			dogBreedComboBox2.getItems().add(breed);
		}
		dogBreedComboBox2.setVisibleRowCount(5);
		dogBreedComboBox2.getSelectionModel().select(0);
		
		HBox dogSizeAndBreedHBox = new HBox();
		dogSizeAndBreedHBox.getChildren().addAll( dogSizeLabel2, dogSizeComboBox2, GUI.emptyVBoxPrinter(),
				dogBreedLabel2,  dogBreedComboBox2, GUI.emptyVBoxPrinter());
		dogSizeAndBreedHBox.setAlignment(Pos.BASELINE_CENTER);
		
		//Gender
		dogGenderCombobox2.getItems().addAll("","Male","Female");
		dogGenderCombobox2.setVisibleRowCount(5);
		dogGenderCombobox2.getSelectionModel().select(0);
		
		//Color
		dogColorComboBox2.getItems().addAll("","Brown","Red","Gold","Yellow","Cream","Black","Blue","Gray","White");
		dogColorComboBox2.setVisibleRowCount(5);
		dogColorComboBox2.getSelectionModel().select(0);
		
		//Age
		dogAgeComboBox2.getItems().add("");
		for (int i = 1; i < 21; i++)
		{
			dogAgeComboBox2.getItems().add(Integer.toString(i));
		}
		dogAgeComboBox2.getSelectionModel().select("");
		dogAgeComboBox2.setVisibleRowCount(5);
		dogAgeComboBox2.getSelectionModel().select(0);
		HBox dogGenderAndColorAndAgeHBox = new HBox();
		dogGenderAndColorAndAgeHBox.getChildren().addAll(dogGenderLabel2, dogGenderCombobox2, GUI.emptyVBoxPrinter(), 
				dogColorLabel2, dogColorComboBox2, GUI.emptyVBoxPrinter(),
				dogAgeLabel2, dogAgeComboBox2, GUI.emptyVBoxPrinter());
		dogGenderAndColorAndAgeHBox.setAlignment(Pos.BASELINE_CENTER);

		HBox buttonsHBox = new HBox();
		buttonsHBox.getChildren().addAll(loginSceneLabel, backToLoginButton, 
				GUI.emptyVBoxPrinter(), goToListLabel, goToListButton, GUI.emptyVBoxPrinter());
		buttonsHBox.setAlignment(Pos.BASELINE_CENTER);

		
		// All that is displayed is here
		adoptDogScene.getChildren().addAll(GUI.emptyHBoxPrinter(), dogSizeAndBreedHBox,
				GUI.emptyHBoxPrinter(), dogGenderAndColorAndAgeHBox,
				GUI.emptyHBoxPrinter(), buttonsHBox, GUI.emptyHBoxPrinter());
		adoptDogScene.setAlignment(Pos.CENTER);
		adoptDogScene.setAlignment(Pos.TOP_CENTER);
	}	
}

