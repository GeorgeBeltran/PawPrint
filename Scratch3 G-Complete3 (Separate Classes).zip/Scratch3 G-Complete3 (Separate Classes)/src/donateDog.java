
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class donateDog {
	public Label dogBreedLabel1 = new Label("Dog Breed");
	public ComboBox<String> dogBreedComboBox1 = new ComboBox<>();
	public Label dogGenderLabel1 = new Label("Dog Gender");
	public ComboBox<String> dogGenderComboBox1 = new ComboBox<>();
	public Label dogSizeLabel1 = new Label("Dog Size");
	public ComboBox<String> dogSizeComboBox1 = new ComboBox<>();
	public Label dogColorLabel1 = new Label("Dog Color");
	public ComboBox<String> dogColorComboBox1 = new ComboBox<>();
	public Label dogAgeLabel1 = new Label("Dog Age");
	public ComboBox<String> dogAgeComboBox1 = new ComboBox<>();
	public Label ownerLabel1 = new Label("Owner Name");
	public TextField ownerTextField1 = new TextField();
	public Label emailLabel1 = new Label("E-mail");
	public TextField emailTextField1 = new TextField();
	public Label phoneLabel1 = new Label("Phone");
	public TextField phoneTextField1 = new TextField();
	
	// Button and Label for going back to loginScene
	Label backToLoginLabel1 = new Label("Back To Login");
	Button backToLoginButton1 = new Button("Click Here!!");

	// Button and Label for going to next Scene
	Label goToInvoiceLabel1 = new Label("Go to Invoice");
	Button goToInvoiceButton1 = new Button("Click Here!!");
	
	public Label getDogBreedLabel1() {
		return dogBreedLabel1;
	}

	public void setDogBreedLabel1(Label dogBreedLabel1) {
		this.dogBreedLabel1 = dogBreedLabel1;
	}

	public ComboBox<String> getDogBreedComboBox1() {
		return dogBreedComboBox1;
	}

	public void setDogBreedComboBox1(ComboBox<String> dogBreedComboBox1) {
		this.dogBreedComboBox1 = dogBreedComboBox1;
	}

	public Label getDogGenderLabel1() {
		return dogGenderLabel1;
	}

	public void setDogGenderLabel1(Label dogGenderLabel1) {
		this.dogGenderLabel1 = dogGenderLabel1;
	}

	public ComboBox<String> getDogGenderComboBox1() {
		return dogGenderComboBox1;
	}

	public void setDogGenderComboBox1(ComboBox<String> dogGenderComboBox1) {
		this.dogGenderComboBox1 = dogGenderComboBox1;
	}

	public Label getDogSizeLabel1() {
		return dogSizeLabel1;
	}

	public void setDogSizeLabel1(Label dogSizeLabel1) {
		this.dogSizeLabel1 = dogSizeLabel1;
	}

	public ComboBox<String> getDogSizeComboBox1() {
		return dogSizeComboBox1;
	}

	public void setDogSizeComboBox1(ComboBox<String> dogSizeComboBox1) {
		this.dogSizeComboBox1 = dogSizeComboBox1;
	}

	public Label getDogColorLabel1() {
		return dogColorLabel1;
	}

	public void setDogColorLabel1(Label dogColorLabel1) {
		this.dogColorLabel1 = dogColorLabel1;
	}

	public ComboBox<String> getDogColorComboBox1() {
		return dogColorComboBox1;
	}

	public void setDogColorComboBox1(ComboBox<String> dogColorComboBox1) {
		this.dogColorComboBox1 = dogColorComboBox1;
	}

	public Label getDogAgeLabel1() {
		return dogAgeLabel1;
	}

	public void setDogAgeLabel1(Label dogAgeLabel1) {
		this.dogAgeLabel1 = dogAgeLabel1;
	}

	public ComboBox<String> getDogAgeComboBox1() {
		return dogAgeComboBox1;
	}

	public void setDogAgeComboBox1(ComboBox<String> dogAgeComboBox1) {
		this.dogAgeComboBox1 = dogAgeComboBox1;
	}

	public Label getOwnerLabel1() {
		return ownerLabel1;
	}

	public void setOwnerLabel1(Label ownerLabel1) {
		this.ownerLabel1 = ownerLabel1;
	}

	public TextField getOwnerTextField1() {
		return ownerTextField1;
	}

	public void setOwnerTextField1(TextField ownerTextField1) {
		this.ownerTextField1 = ownerTextField1;
	}

	public Label getEmailLabel1() {
		return emailLabel1;
	}

	public void setEmailLabel1(Label emailLabel1) {
		this.emailLabel1 = emailLabel1;
	}

	public TextField getEmailTextField1() {
		return emailTextField1;
	}

	public void setEmailTextField1(TextField emailTextField1) {
		this.emailTextField1 = emailTextField1;
	}

	public Label getPhoneLabel1() {
		return phoneLabel1;
	}

	public void setPhoneLabel1(Label phoneLabel1) {
		this.phoneLabel1 = phoneLabel1;
	}

	public TextField getPhoneTextField1() {
		return phoneTextField1;
	}

	public void setPhoneTextField1(TextField phoneTextField1) {
		this.phoneTextField1 = phoneTextField1;
	}

	public VBox getDonateDogScene() {
		return donateDogScene;
	}

	public void setDonateDogScene(VBox donateDogScene) {
		this.donateDogScene = donateDogScene;
	}

	VBox donateDogScene = new VBox();

	public donateDog() {


		/// 1st Row
		// Breed
		dogBreedLabel1.setPrefWidth(100);
		dogBreedComboBox1.getItems().addAll("");
		String[] dogBreeds = GUI.readDogBreedsIntoArray("src\\DogBreeds.txt");
		for (String breed : dogBreeds) {
			dogBreedComboBox1.getItems().add(breed);
		}
		dogBreedComboBox1.setPrefWidth(125);
		dogBreedComboBox1.getSelectionModel().selectFirst();
		dogBreedComboBox1.setVisibleRowCount(5);
		// Gender
		dogGenderLabel1.setPrefWidth(100);
		dogGenderComboBox1.getItems().addAll("", "Male", "Female");
		dogGenderComboBox1.setPrefWidth(125);
		dogGenderComboBox1.getSelectionModel().selectFirst();
		dogGenderComboBox1.setVisibleRowCount(5);
		// Size
		dogSizeLabel1.setPrefWidth(100);
		dogSizeComboBox1.getItems().addAll("", "Small", "Medium", "Large");
		dogSizeComboBox1.setPrefWidth(125);
		dogSizeComboBox1.getSelectionModel().selectFirst();
		dogSizeComboBox1.setVisibleRowCount(5);
		// Color
		dogColorLabel1.setPrefWidth(100);
		dogColorComboBox1.getItems().addAll("", "Brown", "Red", "Gold", "Yellow", "Cream", "Black", "Blue", "Gray",
				"White");
		dogColorComboBox1.setPrefWidth(125);
		dogColorComboBox1.getSelectionModel().selectFirst();
		dogColorComboBox1.setVisibleRowCount(5);

		HBox dogBreedGenderSizeColorHBox = new HBox();
		dogBreedGenderSizeColorHBox.getChildren().addAll(dogBreedLabel1, dogBreedComboBox1, GUI.emptyVBoxPrinter(),
				dogGenderLabel1, dogGenderComboBox1, GUI.emptyVBoxPrinter(), dogSizeLabel1, dogSizeComboBox1,
				GUI.emptyVBoxPrinter(), dogColorLabel1, dogColorComboBox1);
		dogBreedGenderSizeColorHBox.setAlignment(Pos.BASELINE_CENTER);

		/// 2nd Row
		// Age
		dogAgeLabel1.setPrefWidth(100);
		dogAgeComboBox1.getItems().add("");
		for (int i = 1; i < 21; i++) {
			dogAgeComboBox1.getItems().add(Integer.toString(i));
		}
		dogAgeComboBox1.getSelectionModel().select("");
		dogAgeComboBox1.setPrefWidth(125);
		dogAgeComboBox1.getSelectionModel().selectFirst();
		dogAgeComboBox1.setVisibleRowCount(5);
		// OwnerName
		ownerLabel1.setPrefWidth(100);
		ownerTextField1.setPrefWidth(125);
		// Email
		emailLabel1.setPrefWidth(100);
		emailTextField1.setPrefWidth(125);
		// Phone
		phoneLabel1.setPrefWidth(100);
		phoneTextField1.setPrefWidth(125);
		HBox dogAgeOwnerEmailPhoneHBox = new HBox();
		dogAgeOwnerEmailPhoneHBox.getChildren().addAll(dogAgeLabel1, dogAgeComboBox1, GUI.emptyVBoxPrinter(), ownerLabel1,
				ownerTextField1, GUI.emptyVBoxPrinter(), emailLabel1, emailTextField1, GUI.emptyVBoxPrinter(), phoneLabel1,
				phoneTextField1);
		dogAgeOwnerEmailPhoneHBox.setAlignment(Pos.BASELINE_CENTER);

		// CheckPoint
		System.out.println(dogAgeComboBox1.getSelectionModel().getSelectedItem().toString()
				+ dogBreedComboBox1.getSelectionModel().getSelectedItem().toString()
				+ dogGenderComboBox1.getSelectionModel().getSelectedItem().toString()
				+ dogColorComboBox1.getSelectionModel().getSelectedItem().toString()
				+ dogAgeComboBox1.getSelectionModel().getSelectedItem().toString()
				+ ownerTextField1.getText().toString() + emailTextField1.getText().toString()
				+ phoneTextField1.getText().toString() + "here");

		/// 3rd Row Buttons


		HBox buttonsHBox = new HBox();
		buttonsHBox.getChildren().addAll(GUI.emptyVBoxPrinter(), backToLoginLabel1, backToLoginButton1, GUI.emptyVBoxPrinter(),
				goToInvoiceLabel1, goToInvoiceButton1, GUI.emptyVBoxPrinter());
		buttonsHBox.setAlignment(Pos.BASELINE_CENTER);

		// All that is displayed is here
		donateDogScene.getChildren().addAll(GUI.emptyHBoxPrinter(), dogBreedGenderSizeColorHBox, GUI.emptyHBoxPrinter(),
				dogAgeOwnerEmailPhoneHBox, GUI.emptyHBoxPrinter(), buttonsHBox, GUI.emptyHBoxPrinter());
		donateDogScene.setAlignment(Pos.CENTER);
		donateDogScene.setAlignment(Pos.TOP_CENTER);
	}
}
