
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class resultDisplay {
	public 	ComboBox<String> adoptDogListComboBox = new ComboBox<>();
	@SuppressWarnings("rawtypes")
	public TableView adoptDogTableView = new TableView();
	@SuppressWarnings("rawtypes")
	public TableColumn breedColumn = new TableColumn("Breed");
	@SuppressWarnings("rawtypes")
	public TableColumn genderColumn = new TableColumn("Gender");
	@SuppressWarnings("rawtypes")
	public TableColumn sizeColumn = new TableColumn("Size");
	@SuppressWarnings("rawtypes")
	public TableColumn colorColumn = new TableColumn("Color");
	@SuppressWarnings("rawtypes")
	public TableColumn ageColumn = new TableColumn("Age");
	@SuppressWarnings("rawtypes")
	public TableColumn ownerNameColumn = new TableColumn("Owner");
	@SuppressWarnings("rawtypes")
	public TableColumn emailColumn = new TableColumn("Email");
	@SuppressWarnings("rawtypes")
	public TableColumn phoneColumn = new TableColumn("Phone");
	public ObservableList<GUI.Dog> dogObservableList = FXCollections.observableArrayList();
	public Label adoptResultLabel = new Label("Search Results");
	public Label backToLoginLabel2 = new Label("Back To Login");
	public Button backToLoginButton2 = new Button("Click Here!!");

	public Label goToInvoiceLabel2 = new Label("Go to Invoice");
	public Button goToInvoiceButton2 = new Button("Click Here!!");
	
	public VBox adoptDogResultScene = new VBox();
	
	@SuppressWarnings("unchecked")
	public resultDisplay()
	{

		
		breedColumn.setCellValueFactory(
                new PropertyValueFactory<GUI.Dog, String>("breed"));
		genderColumn.setCellValueFactory(
                new PropertyValueFactory<GUI.Dog, String>("gender"));
		sizeColumn.setCellValueFactory(
                new PropertyValueFactory<GUI.Dog, String>("size"));
		colorColumn.setCellValueFactory(
                new PropertyValueFactory<GUI.Dog, String>("color"));
		ageColumn.setCellValueFactory(
                new PropertyValueFactory<GUI.Dog, String>("age"));
		ownerNameColumn.setCellValueFactory(
                new PropertyValueFactory<GUI.Dog, String>("ownerName"));
		emailColumn.setCellValueFactory(
                new PropertyValueFactory<GUI.Dog, String>("email"));
		phoneColumn.setCellValueFactory(
                new PropertyValueFactory<GUI.Dog, String>("phone"));
		


		
		HBox buttonsHBox = new HBox();
		buttonsHBox.getChildren().addAll(GUI.emptyVBoxPrinter(),backToLoginLabel2, backToLoginButton2, 
				GUI.emptyVBoxPrinter(), goToInvoiceLabel2, goToInvoiceButton2, GUI.emptyVBoxPrinter());
		buttonsHBox.setAlignment(Pos.BASELINE_CENTER);
		
		adoptDogTableView.setItems(dogObservableList);
		adoptDogTableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
		adoptDogTableView.getColumns().addAll(breedColumn,genderColumn,sizeColumn,colorColumn,ageColumn,ownerNameColumn,emailColumn,phoneColumn);
		adoptDogResultScene.setSpacing(5);
		adoptDogResultScene.setPadding(new Insets(10,0,0,10));
		adoptDogResultScene.getChildren().addAll(adoptResultLabel,adoptDogTableView,buttonsHBox);
	}
}
