
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class invoiceDisplay {
	public TextArea donateResultTextField = new TextArea();
	
	public VBox donateInvoiceScene = new VBox();
	
	public Button backToLoginButton = new Button("Back To Login");
	
	public invoiceDisplay()
	{

		donateResultTextField.setEditable(false);
		donateResultTextField.setPrefHeight(550);
		donateResultTextField.setPrefRowCount(10);
		donateResultTextField.setPrefColumnCount(20);

		backToLoginButton.setAlignment(Pos.CENTER);
		Button printInvoiceButton = new Button("Print Invoice");
		printInvoiceButton.setAlignment(Pos.CENTER);
		printInvoiceButton.setOnAction(e -> GUI.print(donateResultTextField));
		
		HBox buttonsHBox = new HBox();
		buttonsHBox.getChildren().addAll(GUI.emptyVBoxPrinter(), backToLoginButton, GUI.emptyVBoxPrinter(), printInvoiceButton, GUI.emptyVBoxPrinter());
		buttonsHBox.setAlignment(Pos.CENTER);

		donateInvoiceScene.getChildren().addAll(donateResultTextField,buttonsHBox);
	}
}
