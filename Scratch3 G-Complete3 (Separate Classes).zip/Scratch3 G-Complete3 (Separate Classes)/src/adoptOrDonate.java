
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class adoptOrDonate {
	public Button donateSceneButton = new Button("Donate a Dog");
	public Button adoptSceneButton = new Button("Adopt a Dog");
	public Button backToLoginButton = new Button("Back to Login");
	
	public VBox chooseScene = new VBox();
	
	public Button getDonateSceneButton() {
		return donateSceneButton;
	}

	public void setDonateSceneButton(Button donateSceneButton) {
		this.donateSceneButton = donateSceneButton;
	}

	public Button getAdoptSceneButton() {
		return adoptSceneButton;
	}

	public void setAdoptSceneButton(Button adoptSceneButton) {
		this.adoptSceneButton = adoptSceneButton;
	}

	public Button getBackToLoginButton() {
		return backToLoginButton;
	}

	public void setBackToLoginButton(Button backToLoginButton) {
		this.backToLoginButton = backToLoginButton;
	}

	public VBox getChooseScene() {
		return chooseScene;
	}

	public void setChooseScene(VBox chooseScene) {
		this.chooseScene = chooseScene;
	}

	public adoptOrDonate()
	{

		HBox donateOrAdoptHBox = new HBox();
		donateOrAdoptHBox.getChildren().addAll(GUI.emptyVBoxPrinter(), donateSceneButton, GUI.emptyVBoxPrinter(), adoptSceneButton, GUI.emptyVBoxPrinter());
		donateOrAdoptHBox.setAlignment(Pos.BASELINE_CENTER);

		// Button and Label for going back to loginScene


		HBox returnToLoginHBox = new HBox();
		returnToLoginHBox.getChildren().addAll(backToLoginButton);
		returnToLoginHBox.setAlignment(Pos.BASELINE_CENTER);

		// All that is displayed is here
		chooseScene.getChildren().addAll(GUI.emptyHBoxPrinter(),donateOrAdoptHBox, GUI.emptyHBoxPrinter(), returnToLoginHBox, GUI.emptyHBoxPrinter());
		chooseScene.setAlignment(Pos.CENTER);
		chooseScene.setAlignment(Pos.TOP_CENTER);
	}
	
}
